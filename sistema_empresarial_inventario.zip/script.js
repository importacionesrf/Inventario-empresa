const tasaCambio = 5000; // 1 USD = 5000 COP

// Inputs
const precioCompraCOPInput = document.getElementById('precioCompraCOP');
const precioCompraUSDInput = document.getElementById('precioCompraUSD');
const precioVentaCOPInput = document.getElementById('precioVentaCOP');
const precioVentaUSDInput = document.getElementById('precioVentaUSD');

// Conversión en tiempo real
function actualizarCOP(inputUSD, inputCOP) {
  inputCOP.value = (parseFloat(inputUSD.value) * tasaCambio || 0).toFixed(2);
}
function actualizarUSD(inputCOP, inputUSD) {
  inputUSD.value = (parseFloat(inputCOP.value) / tasaCambio || 0).toFixed(2);
}

precioCompraCOPInput.addEventListener('input', () => actualizarUSD(precioCompraCOPInput, precioCompraUSDInput));
precioCompraUSDInput.addEventListener('input', () => actualizarCOP(precioCompraUSDInput, precioCompraCOPInput));
precioVentaCOPInput.addEventListener('input', () => actualizarUSD(precioVentaCOPInput, precioVentaUSDInput));
precioVentaUSDInput.addEventListener('input', () => actualizarCOP(precioVentaUSDInput, precioVentaCOPInput));

// Form y tabla
const form = document.getElementById('productForm');
const tableBody = document.querySelector('#inventoryTable tbody');

form.addEventListener('submit', function(e) {
  e.preventDefault();

  const producto = document.getElementById('producto').value;
  const precioCompraCOP = parseFloat(precioCompraCOPInput.value);
  const precioCompraUSD = parseFloat(precioCompraUSDInput.value);
  const precioVentaCOP = parseFloat(precioVentaCOPInput.value);
  const precioVentaUSD = parseFloat(precioVentaUSDInput.value);
  const precioEnvio = parseFloat(document.getElementById('precioEnvio').value);
  const deposito = document.getElementById('deposito').value;
  const fechaEntrega = document.getElementById('fechaEntrega').value;
  const estado = document.getElementById('estado').value;

  const gananciaCOP = precioVentaCOP - precioCompraCOP;
  const gananciaUSD = precioVentaUSD - precioCompraUSD;

  const row = document.createElement('tr');
  row.innerHTML = `
    <td>${producto}</td>
    <td>${precioCompraCOP}</td>
    <td>${precioCompraUSD}</td>
    <td>${precioVentaCOP}</td>
    <td>${precioVentaUSD}</td>
    <td>${gananciaCOP}</td>
    <td>${gananciaUSD}</td>
    <td>${precioEnvio}</td>
    <td>${deposito}</td>
    <td>${fechaEntrega}</td>
    <td>${estado}</td>
  `;
  tableBody.appendChild(row);

  form.reset();
});